#!/usr/bin/env python3
"""Airtext local server. No internet, no installs beyond Python 3.
Run:  python3 server.py   (Windows: python server.py)
Then open the printed address on any phone/laptop on the same Wi-Fi or hotspot."""
import json, os, socket, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "8000"))
DATA = os.path.join(HERE, "airtext-data.json")
LOCK = threading.Lock()
DB = {"peers": {}, "msgs": []}
SEEN = {}
try:
    with open(DATA, encoding="utf-8") as f:
        DB = json.load(f)
except Exception:
    pass

def number(pid):
    h = 0
    for c in pid:
        h = (h * 31 + ord(c)) & 0xFFFFFFFF
    return "+1 %s 555 %d" % (["628", "415", "510"][h % 3], 1000 + h % 9000)

def save():
    try:
        with open(DATA, "w", encoding="utf-8") as f:
            json.dump(DB, f)
    except Exception:
        pass

def lan_ips():
    ips = set()
    try:
        for i in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(i[4][0])
    except Exception:
        pass
    for target in ("10.255.255.255", "192.168.255.255"):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((target, 1))
            ips.add(s.getsockname()[0])
            s.close()
        except Exception:
            pass
    return sorted(i for i in ips if not i.startswith("127."))

class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def reply(self, code, body, ctype="application/json"):
        raw = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            with open(os.path.join(HERE, "index.html"), "rb") as f:
                return self.reply(200, f.read(), "text/html; charset=utf-8")
        if u.path == "/api/state":
            pid = (parse_qs(u.query).get("id") or [""])[0]
            with LOCK:
                SEEN[pid] = time.time()
                now = time.time()
                peers = {k: {"name": v["name"], "number": number(k), "online": now - SEEN.get(k, 0) < 6}
                         for k, v in DB["peers"].items()}
                msgs = [m for m in DB["msgs"] if m["from"] == pid or m["to"] == pid]
            return self.reply(200, {"peers": peers, "msgs": msgs})
        self.reply(404, {"error": "not found"})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            b = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self.reply(400, {"error": "bad json"})
        p = urlparse(self.path).path
        with LOCK:
            if p == "/api/join":
                pid, name = str(b.get("id", ""))[:40], str(b.get("name", "Anon")).strip()[:28] or "Anon"
                if not pid:
                    return self.reply(400, {"error": "id"})
                DB["peers"][pid] = {"name": name}
                SEEN[pid] = time.time()
                save()
                return self.reply(200, {"ok": True, "number": number(pid)})
            if p == "/api/send":
                f, t = b.get("from"), b.get("to")
                body = str(b.get("body", ""))[:1000]
                mid = str(b.get("id", ""))[:40]
                if f not in DB["peers"] or t not in DB["peers"] or f == t or not body or not mid:
                    return self.reply(400, {"error": "invalid"})
                if not any(m["id"] == mid for m in DB["msgs"]):
                    DB["msgs"].append({"id": mid, "from": f, "to": t, "body": body,
                                       "at": int(b.get("at") or time.time() * 1000), "read": False})
                    DB["msgs"] = DB["msgs"][-5000:]
                    save()
                return self.reply(200, {"ok": True})
            if p == "/api/read":
                ids = set(b.get("mids") or [])
                for m in DB["msgs"]:
                    if m["id"] in ids and m["to"] == b.get("id"):
                        m["read"] = True
                save()
                return self.reply(200, {"ok": True})
        self.reply(404, {"error": "not found"})

if __name__ == "__main__":
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    print("\nAirtext is running. On each phone/laptop (same Wi-Fi or hotspot) open:\n")
    for ip in lan_ips() or ["<this-computer-ip>"]:
        print("    http://%s:%d" % (ip, PORT))
    print("\nOn this computer: http://localhost:%d\nPress Ctrl+C to stop.\n" % PORT)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
