# Airtext Local (laptop + phones, no internet)

1. Install Python 3 if you don't have it (free, python.org). Mac/Linux usually already have it.
2. Double-click `start-windows.bat` (Windows) or run `./start-mac-linux.sh` (Mac/Linux).
   It prints addresses like http://192.168.1.20:8000
3. Put the phones on the same Wi-Fi as the laptop, or turn on the laptop's/phone's hotspot and join it.
   Internet is NOT needed; mobile data can be off.
4. Open that address in each phone's browser (and the laptop's), enter a name, and text.

Notes: anyone on that network can open the page, so use a network you trust. If a phone can't connect,
allow Python through the laptop firewall when asked. Messages are saved in airtext-data.json.
